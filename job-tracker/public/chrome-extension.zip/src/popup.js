const API_BASE_URL = 'http://localhost:3000/api';

// DOM Elements
const authSection = document.getElementById('authSection');
const mainSection = document.getElementById('mainSection');
const loginForm = document.getElementById('loginForm');
const loginBtn = document.getElementById('loginBtn');
const registerBtn = document.getElementById('registerBtn');
const extractBtn = document.getElementById('extractBtn');
const logoutLink = document.getElementById('logoutLink');
const dashboardLink = document.getElementById('dashboardLink');
const userEmail = document.getElementById('userEmail');
const statusDiv = document.getElementById('status');

// Check authentication on load
document.addEventListener('DOMContentLoaded', async () => {
  const token = await getStoredToken();
  if (token) {
    await checkAuth(token);
  }
});

// Login form submission
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  loginBtn.disabled = true;
  loginBtn.innerHTML = '<span class="loading"></span>';
  
  try {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });
    
    const data = await response.json();
    
    if (response.ok) {
      await chrome.storage.local.set({ token: data.token, user: data.user });
      showMainSection(data.user);
      showStatus('Logged in successfully!', 'success');
    } else {
      showStatus(data.error || 'Login failed', 'error');
    }
  } catch (error) {
    showStatus('Connection error. Please try again.', 'error');
  } finally {
    loginBtn.disabled = false;
    loginBtn.textContent = 'Sign In';
  }
});

// Register button
registerBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: 'http://localhost:3000/register' });
});

// Dashboard link
dashboardLink.addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: 'http://localhost:3000/dashboard' });
});

// Logout
logoutLink.addEventListener('click', async (e) => {
  e.preventDefault();
  
  const token = await getStoredToken();
  if (token) {
    await fetch(`${API_BASE_URL}/auth/logout`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
  }
  
  await chrome.storage.local.remove(['token', 'user']);
  showAuthSection();
  showStatus('Logged out successfully', 'info');
});

// Extract job button
extractBtn.addEventListener('click', async () => {
  extractBtn.disabled = true;
  extractBtn.innerHTML = '<span class="loading"></span>';
  
  try {
    const token = await getStoredToken();
    if (!token) {
      showStatus('Please log in first', 'error');
      showAuthSection();
      return;
    }
    
    // Get current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Inject content script to extract page data
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPageData,
    });
    
    const pageData = results[0].result;
    
    // Send to API
    const response = await fetch(`${API_BASE_URL}/jobs/extract`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({
        url: tab.url,
        html: pageData.html,
        text: pageData.text,
        title: pageData.title,
      }),
    });
    
    const data = await response.json();
    
    if (response.ok) {
      showStatus('Job extracted successfully!', 'success');
      setTimeout(() => {
        chrome.tabs.create({ url: `http://localhost:3000/jobs/${data.job.id}` });
      }, 1500);
    } else {
      showStatus(data.error || 'Extraction failed', 'error');
    }
  } catch (error) {
    console.error('Extraction error:', error);
    showStatus('Failed to extract job. Please try again.', 'error');
  } finally {
    extractBtn.disabled = false;
    extractBtn.textContent = 'Extract Job Offer';
  }
});

// Helper functions
async function getStoredToken() {
  const result = await chrome.storage.local.get('token');
  return result.token;
}

async function checkAuth(token) {
  try {
    const response = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });
    
    if (response.ok) {
      const data = await response.json();
      showMainSection(data.user);
    } else {
      await chrome.storage.local.remove(['token', 'user']);
      showAuthSection();
    }
  } catch (error) {
    console.error('Auth check error:', error);
    showAuthSection();
  }
}

function showAuthSection() {
  authSection.classList.remove('hidden');
  mainSection.classList.add('hidden');
}

function showMainSection(user) {
  authSection.classList.add('hidden');
  mainSection.classList.remove('hidden');
  userEmail.textContent = user.email;
}

function showStatus(message, type) {
  statusDiv.textContent = message;
  statusDiv.className = `status ${type}`;
  statusDiv.style.display = 'block';
  
  setTimeout(() => {
    statusDiv.style.display = 'none';
  }, 5000);
}

// Function to extract page data (runs in the page context)
function extractPageData() {
  const getText = (selector) => {
    const element = document.querySelector(selector);
    return element ? element.textContent.trim() : '';
  };
  
  const getAllText = (selector) => {
    const elements = document.querySelectorAll(selector);
    return Array.from(elements).map(el => el.textContent.trim()).filter(Boolean);
  };
  
  // Try to extract structured data
  const structuredData = {
    // Common job title selectors
    title: getText('h1') || getText('[class*="job-title"]') || getText('[class*="position"]') || document.title,
    
    // Company name
    company: getText('[class*="company"]') || getText('[class*="employer"]') || getText('[class*="organization"]'),
    
    // Location
    location: getText('[class*="location"]') || getText('[class*="address"]') || getText('[class*="city"]'),
    
    // Salary
    salary: getText('[class*="salary"]') || getText('[class*="compensation"]') || getText('[class*="pay"]'),
    
    // Description
    description: getText('[class*="description"]') || getText('[class*="summary"]') || getText('[class*="overview"]'),
    
    // Requirements
    requirements: getAllText('[class*="requirement"]').join('\n') || getAllText('[class*="qualification"]').join('\n'),
    
    // Skills
    skills: getAllText('[class*="skill"]').join(', ') || getAllText('[class*="tech"]').join(', '),
  };
  
  return {
    html: document.documentElement.outerHTML.substring(0, 50000), // Limit size
    text: document.body.innerText.substring(0, 10000), // Limit size
    title: document.title,
    structured: structuredData,
  };
}